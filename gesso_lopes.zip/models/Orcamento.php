<?php
session_start();
require_once 'config/database.php';
require_once 'controllers/ClienteController.php';
require_once 'controllers/ServicoController.php';
require_once 'controllers/OrcamentoController.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$clienteController = new ClienteController();
$servicoController = new ServicoController();
$orcamentoController = new OrcamentoController();

$clientes = $clienteController->listarTodos();
$servicos = $servicoController->listarTodos();
$modelos = $orcamentoController->listarModelos();

$mensagem = '';
$tipo_mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar se é para salvar como modelo
    $salvar_modelo = isset($_POST['salvar_modelo']) && $_POST['salvar_modelo'] == '1';
    
    // Processar dados do formulário
    $cliente_id = $_POST['cliente_id'] ?? 0;
    $observacoes = $_POST['observacoes'] ?? '';
    $itens = [];
    
    // Processar itens do orçamento
    if (isset($_POST['servico_id']) && is_array($_POST['servico_id'])) {
        foreach ($_POST['servico_id'] as $key => $servico_id) {
            if (empty($servico_id)) continue;
            
            $quantidade = floatval($_POST['quantidade'][$key] ?? 0);
            $valor_unitario = floatval($_POST['valor_unitario'][$key] ?? 0);
            
            if ($quantidade > 0 && $valor_unitario > 0) {
                $itens[] = [
                    'servico_id' => $servico_id,
                    'quantidade' => $quantidade,
                    'valor_unitario' => $valor_unitario,
                    'valor_total' => $quantidade * $valor_unitario
                ];
            }
        }
    }
    
    if (!empty($itens)) {
        if ($salvar_modelo) {
            // Salvar como modelo de orçamento
            $nome_modelo = $_POST['nome_modelo'] ?? 'Modelo sem nome';
            $descricao_modelo = $_POST['descricao_modelo'] ?? '';
            $resultado = $orcamentoController->salvarModelo($nome_modelo, $descricao_modelo, $itens);
            
            if ($resultado) {
                $mensagem = 'Modelo de orçamento salvo com sucesso!';
                $tipo_mensagem = 'success';
            } else {
                $mensagem = 'Erro ao salvar modelo de orçamento.';
                $tipo_mensagem = 'error';
            }
        } else {
            // Salvar orçamento normal
            $resultado = $orcamentoController->criar($cliente_id, $observacoes, $itens);
            
            if ($resultado) {
                $id_orcamento = $resultado;
                header('Location: orcamento_visualizar.php?id=' . $id_orcamento . '&mensagem=Orçamento criado com sucesso!');
                exit;
            } else {
                $mensagem = 'Erro ao criar orçamento.';
                $tipo_mensagem = 'error';
            }
        }
    } else {
        $mensagem = 'É necessário adicionar pelo menos um item ao orçamento.';
        $tipo_mensagem = 'error';
    }
}

// Carregar dados de um modelo se especificado
$modelo_id = $_GET['modelo_id'] ?? null;
$itens_modelo = [];
if ($modelo_id) {
    $itens_modelo = $orcamentoController->getItensModelo($modelo_id);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Orçamento - Sistema de Orçamentos Gesso Lopes</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-gray-100 font-montserrat">
    <div class="flex h-screen">
        <!-- Menu lateral -->
        <?php include 'views/templates/sidebar.php'; ?>
        
        <!-- Conteúdo principal -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Cabeçalho -->
            <?php include 'views/templates/header.php'; ?>
            
            <!-- Conteúdo -->
            <main class="flex-1 overflow-y-auto bg-gray-100 p-6">
                <div class="mb-6 flex items-center justify-between">
                    <h1 class="text-2xl font-bold text-gray-800">Criar Orçamento</h1>
                    
                    <div>
                        <a href="orcamentos.php" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition">
                            <i class="fas fa-arrow-left mr-2"></i> Voltar
                        </a>
                    </div>
                </div>
                
                <?php if ($mensagem): ?>
                    <div class="mb-6 bg-<?php echo $tipo_mensagem === 'success' ? 'green' : 'red'; ?>-100 border-l-4 border-<?php echo $tipo_mensagem === 'success' ? 'green' : 'red'; ?>-500 text-<?php echo $tipo_mensagem === 'success' ? 'green' : 'red'; ?>-700 p-4" role="alert">
                        <p><?php echo $mensagem; ?></p>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="orcamentoForm">
                    <div class="bg-white rounded-lg shadow overflow-hidden mb-6">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <h2 class="text-lg font-semibold text-gray-800">Informações do Orçamento</h2>
                        </div>
                        <div class="p-6">
                            <!-- Cliente -->
                            <div class="mb-6">
                                <label for="cliente_id" class="block text-sm font-medium text-gray-700 mb-2">Cliente</label>
                                <div class="flex space-x-2">
                                    <select id="cliente_id" name="cliente_id" class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                        <option value="">Selecione um cliente</option>
                                        <?php foreach ($clientes as $cliente): ?>
                                            <option value="<?php echo $cliente['id']; ?>">
                                                <?php echo $cliente['nome']; ?> 
                                                (<?php echo $cliente['tipo'] === 'F' ? 'CPF: ' . $cliente['cpf_cnpj'] : 'CNPJ: ' . $cliente['cpf_cnpj']; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <a href="cliente_cadastrar.php" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition text-sm">
                                        <i class="fas fa-plus mr-1"></i> Novo Cliente
                                    </a>
                                </div>
                            </div>
                            
                            <!-- Modelo de Orçamento -->
                            <div class="mb-6">
                                <label for="modelo_id" class="block text-sm font-medium text-gray-700 mb-2">Usar Modelo (opcional)</label>
                                <div class="flex space-x-2">
                                    <select id="modelo_id" class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                        <option value="">Selecione um modelo (opcional)</option>
                                        <?php foreach ($modelos as $modelo): ?>
                                            <option value="<?php echo $modelo['id']; ?>"><?php echo $modelo['nome']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="button" id="aplicarModeloBtn" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition text-sm">
                                        <i class="fas fa-check mr-1"></i> Aplicar Modelo
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Observações -->
                            <div class="mb-6">
                                <label for="observacoes" class="block text-sm font-medium text-gray-700 mb-2">Observações</label>
                                <textarea id="observacoes" name="observacoes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                                <p class="text-xs text-gray-500 mt-1">Informações adicionais, condições de pagamento, prazos, etc.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow overflow-hidden mb-6">
                        <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                                                        <h2 class="text-lg font-semibold text-gray-800">Itens do Orçamento</h2>
                            <button type="button" id="adicionarItemBtn" class="inline-flex items-center px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition">
                                <i class="fas fa-plus mr-1"></i> Adicionar Item
                            </button>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200" id="itensTable">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Serviço/Produto</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantidade</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unidade</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valor Unitário</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valor Total</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200" id="itensTableBody">
                                    <!-- Itens serão adicionados aqui via JavaScript -->
                                    <tr class="sem-itens">
                                        <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                            Nenhum item adicionado. Clique em "Adicionar Item" para começar.
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot class="bg-gray-50">
                                    <tr>
                                        <td colspan="4" class="px-6 py-3 text-right text-sm font-medium text-gray-700">Valor Total:</td>
                                        <td class="px-6 py-3 text-left text-sm font-bold text-gray-900" id="valorTotal">R$ 0,00</td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Seção para salvar como modelo -->
                    <div class="bg-white rounded-lg shadow overflow-hidden mb-6">
                        <div class="px-6 py-4 border-b border-gray-200 flex items-center">
                            <input type="checkbox" id="salvarModeloCheck" class="mr-2">
                            <label for="salvarModeloCheck" class="text-lg font-semibold text-gray-800">
                                Salvar como Modelo de Orçamento
                            </label>
                        </div>
                        <div id="salvarModeloFields" class="p-6 hidden">
                            <input type="hidden" name="salvar_modelo" id="salvar_modelo" value="0">
                            
                            <div class="mb-4">
                                <label for="nome_modelo" class="block text-sm font-medium text-gray-700 mb-2">Nome do Modelo</label>
                                <input type="text" id="nome_modelo" name="nome_modelo" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div class="mb-4">
                                <label for="descricao_modelo" class="block text-sm font-medium text-gray-700 mb-2">Descrição</label>
                                <textarea id="descricao_modelo" name="descricao_modelo" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-4">
                        <button type="reset" class="px-6 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition">
                            Limpar
                        </button>
                        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition">
                            Salvar Orçamento
                        </button>
                    </div>
                </form>
                
                <!-- Modal para adicionar item -->
                <div id="adicionarItemModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center hidden z-50">
                    <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                        <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                            <h3 class="text-lg font-semibold text-gray-800">Adicionar Item</h3>
                            <button type="button" id="fecharModalBtn" class="text-gray-400 hover:text-gray-500">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="p-6">
                            <div class="mb-4">
                                <label for="modal_servico_id" class="block text-sm font-medium text-gray-700 mb-2">Serviço/Produto</label>
                                <div class="flex space-x-2">
                                    <select id="modal_servico_id" class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                        <option value="">Selecione um serviço/produto</option>
                                        <?php foreach ($servicos as $servico): ?>
                                            <option 
                                                value="<?php echo $servico['id']; ?>" 
                                                data-unidade="<?php echo $servico['unidade_medida']; ?>"
                                                data-valor="<?php echo $servico['valor_unitario']; ?>">
                                                <?php echo $servico['nome']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <a href="servico_cadastrar.php" class="inline-flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition text-sm">
                                        <i class="fas fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="modal_quantidade" class="block text-sm font-medium text-gray-700 mb-2">Quantidade</label>
                                <input type="number" step="0.01" min="0.01" id="modal_quantidade" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div class="mb-4">
                                <label for="modal_unidade" class="block text-sm font-medium text-gray-700 mb-2">Unidade de Medida</label>
                                <input type="text" id="modal_unidade" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-100" readonly>
                            </div>
                            
                            <div class="mb-4">
                                <label for="modal_valor_unitario" class="block text-sm font-medium text-gray-700 mb-2">Valor Unitário (R$)</label>
                                <input type="number" step="0.01" min="0.01" id="modal_valor_unitario" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div class="mb-4">
                                <label for="modal_valor_total" class="block text-sm font-medium text-gray-700 mb-2">Valor Total (R$)</label>
                                <input type="text" id="modal_valor_total" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-100" readonly>
                            </div>
                        </div>
                        <div class="px-6 py-4 bg-gray-50 flex justify-end">
                            <button type="button" id="cancelarItemBtn" class="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition mr-4">
                                Cancelar
                            </button>
                            <button type="button" id="confirmarItemBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition">
                                Adicionar
                            </button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const adicionarItemBtn = document.getElementById('adicionarItemBtn');
            const adicionarItemModal = document.getElementById('adicionarItemModal');
            const fecharModalBtn = document.getElementById('fecharModalBtn');
            const cancelarItemBtn = document.getElementById('cancelarItemBtn');
            const confirmarItemBtn = document.getElementById('confirmarItemBtn');
            const itensTableBody = document.getElementById('itensTableBody');
            const salvarModeloCheck = document.getElementById('salvarModeloCheck');
            const salvarModeloFields = document.getElementById('salvarModeloFields');
            const salvarModeloInput = document.getElementById('salvar_modelo');
            const aplicarModeloBtn = document.getElementById('aplicarModeloBtn');
            
            let itemIndex = 0;
            let editingIndex = null;
            
            // Abrir modal de adição de item
            adicionarItemBtn.addEventListener('click', function() {
                adicionarItemModal.classList.remove('hidden');
                resetModal();
            });
            
            // Fechar modal
            function fecharModal() {
                adicionarItemModal.classList.add('hidden');
                resetModal();
            }
            
            fecharModalBtn.addEventListener('click', fecharModal);
            cancelarItemBtn.addEventListener('click', fecharModal);
            
            // Resetar campos do modal
            function resetModal() {
                document.getElementById('modal_servico_id').value = '';
                document.getElementById('modal_quantidade').value = '';
                document.getElementById('modal_unidade').value = '';
                document.getElementById('modal_valor_unitario').value = '';
                document.getElementById('modal_valor_total').value = '';
                editingIndex = null;
            }
            
            // Atualizar valor total do modal
            function atualizarValorTotalModal() {
                const quantidade = parseFloat(document.getElementById('modal_quantidade').value) || 0;
                const valorUnitario = parseFloat(document.getElementById('modal_valor_unitario').value) || 0;
                const valorTotal = quantidade * valorUnitario;
                document.getElementById('modal_valor_total').value = valorTotal.toFixed(2);
            }
            
            // Eventos para atualizar valor total no modal
            document.getElementById('modal_quantidade').addEventListener('input', atualizarValorTotalModal);
            document.getElementById('modal_valor_unitario').addEventListener('input', atualizarValorTotalModal);
            
            // Ao selecionar um serviço, preencher unidade e valor
            document.getElementById('modal_servico_id').addEventListener('change', function() {
                const option = this.options[this.selectedIndex];
                if (option && option.value) {
                    document.getElementById('modal_unidade').value = option.dataset.unidade;
                    document.getElementById('modal_valor_unitario').value = option.dataset.valor;
                    atualizarValorTotalModal();
                } else {
                    document.getElementById('modal_unidade').value = '';
                    document.getElementById('modal_valor_unitario').value = '';
                    document.getElementById('modal_valor_total').value = '';
                }
            });
            
            // Adicionar item ao orçamento
            confirmarItemBtn.addEventListener('click', function() {
                const servicoId = document.getElementById('modal_servico_id').value;
                const servicoText = document.getElementById('modal_servico_id').options[document.getElementById('modal_servico_id').selectedIndex].text;
                const quantidade = document.getElementById('modal_quantidade').value;
                const unidade = document.getElementById('modal_unidade').value;
                const valorUnitario = document.getElementById('modal_valor_unitario').value;
                const valorTotal = document.getElementById('modal_valor_total').value;
                
                if (!servicoId || !quantidade || !valorUnitario) {
                    alert('Por favor, preencha todos os campos obrigatórios.');
                    return;
                }
                
                // Remover a linha "sem itens" se existir
                const semItensRow = itensTableBody.querySelector('.sem-itens');
                if (semItensRow) {
                    semItensRow.remove();
                }
                
                let row;
                if (editingIndex !== null) {
                    // Editando um item existente
                    row = document.querySelector(`tr[data-index="${editingIndex}"]`);
                } else {
                    // Criando um novo item
                    row = document.createElement('tr');
                    row.setAttribute('data-index', itemIndex++);
                }
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${servicoText}
                        <input type="hidden" name="servico_id[]" value="${servicoId}">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${quantidade}
                        <input type="hidden" name="quantidade[]" value="${quantidade}">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${unidade}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        R$ ${parseFloat(valorUnitario).toFixed(2)}
                        <input type="hidden" name="valor_unitario[]" value="${valorUnitario}">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        R$ ${parseFloat(valorTotal).toFixed(2)}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <button type="button" class="text-indigo-600 hover:text-indigo-900 mr-3 editar-item">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="text-red-600 hover:text-red-900 remover-item">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                
                if (editingIndex === null) {
                    itensTableBody.appendChild(row);
                }
                
                // Adicionar event listeners para os botões
                const editarBtns = row.querySelectorAll('.editar-item');
                const removerBtns = row.querySelectorAll('.remover-item');
                
                editarBtns.forEach(btn => {
                    btn.addEventListener('click', function() {
                        const row = this.closest('tr');
                        editarItem(row);
                    });
                });
                
                removerBtns.forEach(btn => {
                    btn.addEventListener('click', function() {
                        const row = this.closest('tr');
                        removerItem(row);
                    });
                });
                
                atualizarValorTotalOrcamento();
                fecharModal();
            });
            
            // Editar item
            function editarItem(row) {
                editingIndex = row.getAttribute('data-index');
                
                const servicoId = row.querySelector('input[name="servico_id[]"]').value;
                const quantidade = row.querySelector('input[name="quantidade[]"]').value;
                const valorUnitario = row.querySelector('input[name="valor_unitario[]"]').value;
                
                document.getElementById('modal_servico_id').value = servicoId;
                document.getElementById('modal_quantidade').value = quantidade;
                
                // Disparar evento change para preencher unidade
                const event = new Event('change');
                document.getElementById('modal_servico_id').dispatchEvent(event);
                
                document.getElementById('modal_valor_unitario').value = valorUnitario;
                atualizarValorTotalModal();
                
                adicionarItemModal.classList.remove('hidden');
            }
            
            // Remover item
            function removerItem(row) {
                if (confirm('Tem certeza que deseja remover este item?')) {
                    row.remove();
                    atualizarValorTotalOrcamento();
                    
                    // Se não houver mais itens, mostrar mensagem
                    if (itensTableBody.children.length === 0) {
                        const semItensRow = document.createElement('tr');
                        semItensRow.className = 'sem-itens';
                        semItensRow.innerHTML = `
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                Nenhum item adicionado. Clique em "Adicionar Item" para começar.
                            </td>
                        `;
                        itensTableBody.appendChild(semItensRow);
                    }
                }
            }
            
            // Atualizar valor total do orçamento
            function atualizarValorTotalOrcamento() {
                let total = 0;
                const rows = itensTableBody.querySelectorAll('tr:not(.sem-itens)');
                
                rows.forEach(row => {
                    const valorTotalText = row.querySelectorAll('td')[4].innerText;
                    const valorTotal = parseFloat(valorTotalText.replace('R$ ', '').replace(',', '.')) || 0;
                    total += valorTotal;
                });
                
                document.getElementById('valorTotal').innerText = `R$ ${total.toFixed(2)}`;
            }
            
            // Salvar como modelo
            salvarModeloCheck.addEventListener('change', function() {
                if (this.checked) {
                    salvarModeloFields.classList.remove('hidden');
                    salvarModeloInput.value = '1';
                } else {
                    salvarModeloFields.classList.add('hidden');
                    salvarModeloInput.value = '0';
                }
            });
            
            // Aplicar modelo
            aplicarModeloBtn.addEventListener('click', function() {
                const modeloId = document.getElementById('modelo_id').value;
                
                if (!modeloId) {
                    alert('Por favor, selecione um modelo.');
                    return;
                }
                
                // Redirecionar para a mesma página com o parâmetro modelo_id
                window.location.href = `orcamento_criar.php?modelo_id=${modeloId}`;
            });
            
            <?php if (!empty($itens_modelo)): ?>
            // Carregar itens do modelo selecionado
            <?php foreach ($itens_modelo as $item): ?>
                document.getElementById('modal_servico_id').value = '<?php echo $item['servico_id']; ?>';
                document.getElementById('modal_servico_id').dispatchEvent(new Event('change'));
                document.getElementById('modal_quantidade').value = '<?php echo $item['quantidade']; ?>';
                atualizarValorTotalModal();
                confirmarItemBtn.click();
            <?php endforeach; ?>
            <?php endif; ?>
        });
    </script>
</body>
</html>
