<?php
require_once 'vendor/autoload.php'; // Usando dompdf

class PDFGenerator {
    public function gerarOrcamentoPDF($orcamento) {
        // Configurar dompdf
        $options = new \Dompdf\Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'DejaVu Sans');
        
        $dompdf = new \Dompdf\Dompdf($options);
        
        // Obter dados do orçamento
        $cliente = $orcamento['cliente'];
        $itens = $orcamento['itens'];
        $data = date('d/m/Y', strtotime($orcamento['data_criacao']));
        $valorTotal = number_format($orcamento['valor_total'], 2, ',', '.');
        
        // Gerar HTML para o PDF
        $html = $this->gerarHTMLOrcamento($orcamento, $cliente, $itens, $data, $valorTotal);
        
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4');
        $dompdf->render();
        
        // Salvar o arquivo
        $output = $dompdf->output();
        $pdfPath = 'uploads/orcamentos/orcamento_' . $orcamento['id'] . '.pdf';
        file_put_contents($pdfPath, $output);
        
        return $pdfPath;
    }
    
    private function gerarHTMLOrcamento($orcamento, $cliente, $itens, $data, $valorTotal) {
        // Logo e cabeçalho
        $html = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Orçamento #' . $orcamento['id'] . ' - Gesso Lopes</title>
            <style>
                body {
                    font-family: "DejaVu Sans", sans-serif;
                    line-height: 1.6;
                    color: #333;
                    margin: 0;
                    padding: 20px;
                }
                .header {
                    text-align: center;
                    margin-bottom: 30px;
                }
                .logo {
                    max-width: 180px;
                    margin-bottom: 10px;
                }
                .company-name {
                    font-size: 24px;
                    font-weight: bold;
                    color: #0066cc;
                    margin: 10px 0 5px;
                }
                .company-info {
                    font-size: 12px;
                    color: #666;
                    margin-bottom: 5px;
                }
                .document-title {
                    font-size: 20px;
                    font-weight: bold;
                    margin: 20px 0;
                    color: #333;
                    border-bottom: 2px solid #0066cc;
                    padding-bottom: 5px;
                }
                .section {
                    margin-bottom: 20px;
                }
                .section-title {
                    font-size: 14px;
                    font-weight: bold;
                    margin-bottom: 10px;
                    color: #0066cc;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 20px;
                }
                th {
                    background-color: #f0f0f0;
                    text-align: left;
                    padding: 8px;
                    font-size: 12px;
                    border-bottom: 1px solid #ddd;
                }
                td {
                    padding: 8px;
                    font-size: 12px;
                    border-bottom: 1px solid #ddd;
                }
                .total {
                    font-weight: bold;
                    font-size: 14px;
                }
                .observations {
                    background-color: #f9f9f9;
                    padding: 10px;
                    border-radius: 4px;
                    font-size: 12px;
                }
                .footer {
                    margin-top: 30px;
                    font-size: 12px;
                    color: #666;
                    text-align: center;
                }
                .signature {
                    margin-top: 50px;
                    text-align: center;
                }
                .signature-line {
                    width: 70%;
                    margin: 0 auto;
                    border-top: 1px solid #000;
                    padding-top: 5px;
                    font-size: 12px;
                }
                .page-break {
                    page-break-after: always;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <img src="assets/img/logo.png" class="logo" />
                <div class="company-name">Gesso Lopes</div>
                <div class="company-info">Especialista em Gesso e Drywall</div>
                <div class="company-info">Telefone: (XX) XXXXX-XXXX | E-mail: contato@gessolopes.com.br</div>
            </div>
            
            <div class="document-title">
                Orçamento #' . $orcamento['id'] . ' - Data: ' . $data . '
            </div>
            
            <div class="section">
                <div class="section-title">Dados do Cliente</div>
                <table>
                    <tr>
                        <td><strong>Nome:</strong> ' . $cliente['nome'] . '</td>
                        <td><strong>' . ($cliente['tipo'] === 'F' ? 'CPF' : 'CNPJ') . ':</strong> ' . $cliente['cpf_cnpj'] . '</td>
                    </tr>
                    <tr>
                        <td><strong>Telefone:</strong> ' . $cliente['telefone'] . '</td>
                        <td><strong>E-mail:</strong> ' . $cliente['email'] . '</td>
                    </tr>
                    <tr>
                        <td colspan="2"><strong>Endereço:</strong> ' . $cliente['endereco'] . ', ' . $cliente['cidade'] . '/' . $cliente['estado'] . '</td>
                    </tr>
                </table>
            </div>
            
            <div class="section">
                <div class="section-title">Itens do Orçamento</div>
                        <table>
                    <thead>
                        <tr>
                            <th style="width: 5%;">#</th>
                            <th style="width: 35%;">Serviço/Produto</th>
                            <th style="width: 10%;">Qtde.</th>
                            <th style="width: 10%;">Unidade</th>
                            <th style="width: 20%;">Valor Unit.</th>
                            <th style="width: 20%;">Valor Total</th>
                        </tr>
                    </thead>
                    <tbody>';

        // Itens do orçamento
        foreach ($itens as $index => $item) {
            $html .= '
                        <tr>
                            <td>' . ($index + 1) . '</td>
                            <td>' . $item['servico_nome'] . '</td>
                            <td>' . number_format($item['quantidade'], 2, ',', '.') . '</td>
                            <td>' . $item['unidade_medida'] . '</td>
                            <td>R$ ' . number_format($item['valor_unitario'], 2, ',', '.') . '</td>
                            <td>R$ ' . number_format($item['valor_total'], 2, ',', '.') . '</td>
                        </tr>';
        }

        $html .= '
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" align="right" class="total">VALOR TOTAL:</td>
                            <td class="total">R$ ' . $valorTotal . '</td>
                        </tr>
                    </tfoot>
                </table>
            </div>';

        // Observações
        if (!empty($orcamento['observacoes'])) {
            $html .= '
            <div class="section">
                <div class="section-title">Observações</div>
                <div class="observations">
                    ' . nl2br($orcamento['observacoes']) . '
                </div>
            </div>';
        }

        // Informações de pagamento padrão
        $html .= '
            <div class="section">
                <div class="section-title">Condições de Pagamento</div>
                <div class="observations">
                    <p>• 50% de entrada para início dos serviços</p>
                    <p>• 50% no término da obra</p>
                    <p>• Aceitamos PIX, transferência bancária e cartão de crédito (até 3x sem juros)</p>
                </div>
            </div>';

        // Assinatura
        $html .= '
            <div class="signature">
                <div class="signature-line">Assinatura do Cliente</div>
            </div>
            
            <div class="footer">
                <p>Este orçamento é válido por 15 dias a partir da data de emissão.</p>
                <p>Gesso Lopes - Especialista em Gesso e Drywall</p>
            </div>
        </body>
        </html>';

        return $html;
    }
}
