<?php
session_start();
require_once 'config/database.php';
require_once 'controllers/OrcamentoController.php';
require_once 'utils/PDFGenerator.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o ID do orçamento foi fornecido
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: orcamentos.php?erro=Orçamento não especificado');
    exit;
}

$id = intval($_GET['id']);
$orcamentoController = new OrcamentoController();
$orcamento = $orcamentoController->getById($id);

if (!$orcamento) {
    header('Location: orcamentos.php?erro=Orçamento não encontrado');
    exit;
}

// Gerar PDF do orçamento
$pdfGenerator = new PDFGenerator();
$pdfPath = $pdfGenerator->gerarOrcamentoPDF($orcamento);

// Enviar por WhatsApp
if (isset($_GET['whatsapp']) && $_GET['whatsapp'] === '1') {
    $cliente = $orcamento['cliente'];
    $whatsapp = $cliente['whatsapp'] ?? $cliente['telefone'] ?? '';
    
    if (!empty($whatsapp)) {
        // Remover formatação do número
        $whatsapp = preg_replace('/\D/', '', $whatsapp);
        
        // Formatação do texto
        $mensagem = "Olá {$cliente['nome']}, segue o orçamento #{$orcamento['id']} da Gesso Lopes. Valor total: R$ " . number_format($orcamento['valor_total'], 2, ',', '.') . ". Em caso de dúvidas, estamos à disposição.";
        $mensagem = urlencode($mensagem);
        
        // Redirecionar para o WhatsApp Web
        $whatsappUrl = "https://wa.me/{$whatsapp}?text={$mensagem}";
        header('Location: ' . $whatsappUrl);
        exit;
    } else {
        header('Location: orcamento_visualizar.php?id=' . $id . '&erro=Cliente não possui número de WhatsApp cadastrado');
        exit;
    }
} else {
    // Exibir o PDF diretamente no navegador
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="orcamento_' . $id . '.pdf"');
    header('Content-Length: ' . filesize($pdfPath));
    readfile($pdfPath);
    exit;
}
?>
