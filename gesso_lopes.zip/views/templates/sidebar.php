<div class="bg-blue-800 text-white w-64 flex-shrink-0 hidden md:block">
    <div class="p-4 flex items-center">
        <img src="assets/img/logo_white.png" alt="Gesso Lopes" class="h-10 mr-2">
        <span class="text-xl font-semibold">Gesso Lopes</span>
    </div>
    
    <nav class="px-4 pb-4">
        <ul>
            <li class="mb-2">
                <a href="dashboard.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'bg-blue-700' : ''; ?>">
                    <i class="fas fa-tachometer-alt w-6"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="mb-2">
                <a href="orcamentos.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition <?php echo basename($_SERVER['PHP_SELF']) === 'orcamentos.php' ? 'bg-blue-700' : ''; ?>">
                    <i class="fas fa-file-invoice-dollar w-6"></i>
                    <span>Orçamentos</span>
                </a>
            </li>
            <li class="mb-2">
                <a href="clientes.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition <?php echo basename($_SERVER['PHP_SELF']) === 'clientes.php' ? 'bg-blue-700' : ''; ?>">
                    <i class="fas fa-users w-6"></i>
                    <span>Clientes</span>
                </a>
            </li>
            <li class="mb-2">
                <a href="servicos.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition <?php echo basename($_SERVER['PHP_SELF']) === 'servicos.php' ? 'bg-blue-700' : ''; ?>">
                    <i class="fas fa-tools w-6"></i>
                    <span>Serviços</span>
                </a>
            </li>
            <li class="mb-2">
                <a href="modelos.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition <?php echo basename($_SERVER['PHP_SELF']) === 'modelos.php' ? 'bg-blue-700' : ''; ?>">
                    <i class="fas fa-copy w-6"></i>
                    <span>Modelos</span>
                </a>
            </li>
            <li class="border-t border-blue-700 my-4 pt-4">
                <a href="configuracoes.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition <?php echo basename($_SERVER['PHP_SELF']) === 'configuracoes.php' ? 'bg-blue-700' : ''; ?>">
                    <i class="fas fa-cog w-6"></i>
                    <span>Configurações</span>
                </a>
            </li>
            <li class="mb-2">
                <a href="logout.php" class="flex items-center p-3 text-white hover:bg-blue-700 rounded-md transition">
                    <i class="fas fa-sign-out-alt w-6"></i>
                    <span>Sair</span>
                </a>
            </li>
        </ul>
    </nav>
</div>
