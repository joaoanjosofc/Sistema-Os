<header class="bg-white shadow h-16 flex items-center px-6">
    <button id="toggleSidebarBtn" class="mr-4 text-gray-500 md:hidden">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="flex-1"></div>
    
    <div class="flex items-center">
        <div class="mr-4 text-sm text-gray-700">
            <span class="hidden md:inline">Bem-vindo,</span>
            <span class="font-medium"><?php echo $_SESSION['usuario_nome'] ?? 'Usuário'; ?></span>
        </div>
        <div class="relative">
            <button id="userMenuBtn" class="overflow-hidden rounded-full w-8 h-8 border border-gray-300 flex items-center justify-center bg-gray-200 text-gray-700">
                <i class="fas fa-user text-sm"></i>
            </button>
            <div id="userMenu" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden z-10">
                <a href="perfil.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Meu Perfil</a>
                <a href="configuracoes.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Configurações</a>
                <div class="border-t border-gray-100"></div>
                <a href="logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sair</a>
            </div>
        </div>
    </div>
</header>

<script>
    // Toggle menu de usuário
    document.getElementById('userMenuBtn').addEventListener('click', function() {
        document.getElementById('userMenu').classList.toggle('hidden');
    });
    
    // Fechar ao clicar fora
    document.addEventListener('click', function(event) {
        const userMenu = document.getElementById('userMenu');
        const userMenuBtn = document.getElementById('userMenuBtn');
        
        if (!userMenuBtn.contains(event.target) && !userMenu.contains(event.target) && !userMenu.classList.contains('hidden')) {
            userMenu.classList.add('hidden');
        }
    });
    
    // Toggle sidebar em mobile
    document.getElementById('toggleSidebarBtn').addEventListener('click', function() {
        const sidebar = document.querySelector('.bg-blue-800');
        sidebar.classList.toggle('hidden');
    });
</script>


