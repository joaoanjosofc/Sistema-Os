<?php
session_start();
require_once 'config/database.php';
require_once 'controllers/OrcamentoController.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$orcamentoController = new OrcamentoController();
$resumo = $orcamentoController->getResumoDashboard();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Orçamentos Gesso Lopes</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-gray-100 font-montserrat">
    <div class="flex h-screen">
        <!-- Menu lateral -->
        <?php include 'views/templates/sidebar.php'; ?>
        
        <!-- Conteúdo principal -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Cabeçalho -->
            <?php include 'views/templates/header.php'; ?>
            
            <!-- Conteúdo -->
            <main class="flex-1 overflow-y-auto bg-gray-100 p-6">
                <h1 class="text-2xl font-bold text-gray-800 mb-6">Dashboard</h1>
                
                <!-- Cards de resumo -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <!-- Total de orçamentos -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                                <i class="fas fa-file-invoice text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500 font-medium">Total de Orçamentos</p>
                                <p class="text-2xl font-semibold"><?php echo $resumo['total_orcamentos']; ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Orçamentos aprovados -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-green-100 text-green-600">
                                <i class="fas fa-check-circle text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500 font-medium">Orçamentos Aprovados</p>
                                <p class="text-2xl font-semibold"><?php echo $resumo['orcamentos_aprovados']; ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Orçamentos pendentes -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                                <i class="fas fa-clock text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500 font-medium">Orçamentos Pendentes</p>
                                <p class="text-2xl font-semibold"><?php echo $resumo['orcamentos_pendentes']; ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Total em R$ de orçamentos aprovados -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 rounded-full bg-indigo-100 text-indigo-600">
                                <i class="fas fa-money-bill-wave text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500 font-medium">Valor Aprovado (R$)</p>
                                <p class="text-2xl font-semibold">R$ <?php echo number_format($resumo['valor_aprovado'], 2, ',', '.'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Orçamentos recentes -->
                <div class="bg-white rounded-lg shadow overflow-hidden mb-8">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-lg font-semibold text-gray-800">Orçamentos Recentes</h2>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valor</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($resumo['orcamentos_recentes'] as $orcamento): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">#<?php echo $orcamento['id']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo $orcamento['cliente']; ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('d/m/Y', strtotime($orcamento['data_criacao'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        R$ <?php echo number_format($orcamento['valor_total'], 2, ',', '.'); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($orcamento['status'] === 'aprovado'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Aprovado
                                            </span>
                                        <?php elseif ($orcamento['status'] === 'enviado'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                Enviado
                                            </span>
                                        <?php elseif ($orcamento['status'] === 'recusado'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                Recusado
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                Pendente
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="orcamento_visualizar.php?id=<?php echo $orcamento['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="orcamento_pdf.php?id=<?php echo $orcamento['id']; ?>" class="text-gray-600 hover:text-gray-900 mr-3">
                                            <i class="fas fa-file-pdf"></i>
                                        </a>
                                        <a href="orcamento_whatsapp.php?id=<?php echo $orcamento['id']; ?>" class="text-green-600 hover:text-green-900">
                                            <i class="fab fa-whatsapp"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Botões de ação rápida -->
                <div class="flex flex-wrap gap-4">
                    <a href="orcamento_criar.php" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition">
                        <i class="fas fa-plus-circle mr-2"></i> Novo Orçamento
                    </a>
                    <a href="cliente_cadastrar.php" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition">
                        <i class="fas fa-user-plus mr-2"></i> Novo Cliente
                    </a>
                    <a href="servico_cadastrar.php" class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition">
                        <i class="fas fa-tools mr-2"></i> Novo Serviço
                    </a>
                </div>
            </main>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>
