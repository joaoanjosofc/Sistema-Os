<?php
class OrcamentoController {
    private $db;
    
    public function __construct() {
        $this->db = new PDO('sqlite:database.sqlite');
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    
    public function getById($id) {
        try {
            // Obter dados do orçamento
            $stmt = $this->db->prepare('
                SELECT o.*, c.nome as cliente_nome, c.tipo, c.cpf_cnpj, c.telefone, c.whatsapp, 
                       c.email, c.endereco, c.cidade, c.estado 
                FROM orcamentos o
                JOIN clientes c ON o.cliente_id = c.id
                WHERE o.id = ?
            ');
            $stmt->execute([$id]);
            $orcamento = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$orcamento) {
                return false;
            }
            
            // Obter itens do orçamento
            $stmt = $this->db->prepare('
                SELECT oi.*, s.nome as servico_nome, s.unidade_medida
                FROM orcamento_itens oi
                JOIN servicos s ON oi.servico_id = s.id
                WHERE oi.orcamento_id = ?
            ');
            $stmt->execute([$id]);
            $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Montar objeto completo
            return [
                'id' => $orcamento['id'],
                'data_criacao' => $orcamento['data_criacao'],
                'valor_total' => $orcamento['valor_total'],
                'observacoes' => $orcamento['observacoes'],
                'status' => $orcamento['status'],
                'cliente' => [
                    'nome' => $orcamento['cliente_nome'],
                    'tipo' => $orcamento['tipo'],
                    'cpf_cnpj' => $orcamento['cpf_cnpj'],
                    'telefone' => $orcamento['telefone'],
                    'whatsapp' => $orcamento['whatsapp'],
                    'email' => $orcamento['email'],
                    'endereco' => $orcamento['endereco'],
                    'cidade' => $orcamento['cidade'],
                    'estado' => $orcamento['estado']
                ],
                'itens' => $itens
            ];
        } catch (PDOException $e) {
            error_log('Erro ao buscar orçamento: ' . $e->getMessage());
            return false;
        }
    }
    
    public function getResumoDashboard() {
        try {
            // Total de orçamentos
            $stmt = $this->db->query('SELECT COUNT(*) FROM orcamentos');
            $total_orcamentos = $stmt->fetchColumn();
            
            // Orçamentos aprovados
            $stmt = $this->db->query('SELECT COUNT(*) FROM orcamentos WHERE status = "aprovado"');
            $orcamentos_aprovados = $stmt->fetchColumn();
            
            // Orçamentos pendentes
            $stmt = $this->db->query('SELECT COUNT(*) FROM orcamentos WHERE status = "pendente" OR status = "enviado"');
            $orcamentos_pendentes = $stmt->fetchColumn();
            
            // Valor total aprovado
            $stmt = $this->db->query('SELECT SUM(valor_total) FROM orcamentos WHERE status = "aprovado"');
            $valor_aprovado = $stmt->fetchColumn() ?: 0;
            
            // Orçamentos recentes
            $stmt = $this->db->query('
                SELECT o.id, o.data_criacao, o.valor_total, o.status, c.nome as cliente
                FROM orcamentos o
                JOIN clientes c ON o.cliente_id = c.id
                ORDER BY o.data_criacao DESC
                LIMIT 5
            ');
            $orcamentos_recentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return [
                'total_orcamentos' => $total_orcamentos,
                'orcamentos_aprovados' => $orcamentos_aprovados,
                'orcamentos_pendentes' => $orcamentos_pendentes,
                'valor_aprovado' => $valor_aprovado,
                'orcamentos_recentes' => $orcamentos_recentes
            ];
        } catch (PDOException $e) {
            error_log('Erro ao obter resumo do dashboard: ' . $e->getMessage());
            return [
                'total_orcamentos' => 0,
                'orcamentos_aprovados' => 0,
                'orcamentos_pendentes' => 0,
                'valor_aprovado' => 0,
                'orcamentos_recentes' => []
            ];
        }
    }
    
    public function listar($filtros = []) {
        try {
            $sql = '
                SELECT o.*, c.nome as cliente
                FROM orcamentos o
                JOIN clientes c ON o.cliente_id = c.id
                WHERE 1=1
            ';
            $params = [];
            
            // Aplicar filtros
            if (isset($filtros['cliente_id']) && $filtros['cliente_id']) {
                $sql .= ' AND o.cliente_id = ?';
                $params[] = $filtros['cliente_id'];
            }
            
            if (isset($filtros['status']) && $filtros['status']) {
                $sql .= ' AND o.status = ?';
                $params[] = $filtros['status'];
            }
            
            if (isset($filtros['data_inicio']) && $filtros['data_inicio']) {
                $sql .= ' AND o.data_criacao >= ?';
                $params[] = $filtros['data_inicio'] . ' 00:00:00';
            }
            
            if (isset($filtros['data_fim']) && $filtros['data_fim']) {
                $sql .= ' AND o.data_criacao <= ?';
                $params[] = $filtros['data_fim'] . ' 23:59:59';
            }
            
            $sql .= ' ORDER BY o.data_criacao DESC';
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Erro ao listar orçamentos: ' . $e->getMessage());
            return [];
        }
    }
    
    public function criar($cliente_id, $observacoes, $itens) {
        try {
            $this->db->beginTransaction();
            
            // Calcular valor total
            $valor_total = 0;
            foreach ($itens as $item) {
                $valor_total += $item['valor_total'];
            }
            
            // Inserir orçamento
            $stmt = $this->db->prepare('
                INSERT INTO orcamentos (cliente_id, valor_total, observacoes, status)
                VALUES (?, ?, ?, "pendente")
            ');
            $stmt->execute([$cliente_id, $valor_total, $observacoes]);
            $orcamento_id = $this->db->lastInsertId();
            
            // Inserir itens
            foreach ($itens as $item) {
                $stmt = $this->db->prepare('
                    INSERT INTO orcamento_itens (orcamento_id, servico_id, quantidade, valor_unitario, valor_total)
                    VALUES (?, ?, ?, ?, ?)
                ');
                $stmt->execute([
                    $orcamento_id,
                    $item['servico_id'],
                    $item['quantidade'],
                    $item['valor_unitario'],
                    $item['valor_total']
                ]);
            }
            
            $this->db->commit();
            return $orcamento_id;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log('Erro ao criar orçamento: ' . $e->getMessage());
            return false;
        }
    }
    
    public function atualizar($id, $cliente_id, $observacoes, $itens, $status = null) {
        try {
            $this->db->beginTransaction();
            
            // Calcular valor total
            $valor_total = 0;
            foreach ($itens as $item) {
                $valor_total += $item['valor_total'];
            }
            
            // Atualizar orçamento
            $sql = 'UPDATE orcamentos SET cliente_id = ?, valor_total = ?, observacoes = ?';
            $params = [$cliente_id, $valor_total, $observacoes];
            
            if ($status !== null) {
                $sql .= ', status = ?';
                $params[] = $status;
            }
            
            $sql .= ' WHERE id = ?';
            $params[] = $id;
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            // Remover itens antigos
            $stmt = $this->db->prepare('DELETE FROM orcamento_itens WHERE orcamento_id = ?');
            $stmt->execute([$id]);
            
            // Inserir novos itens
            foreach ($itens as $item) {
                $stmt = $this->db->prepare('
                    INSERT INTO orcamento_itens (orcamento_id, servico_id, quantidade, valor_unitario, valor_total)
                    VALUES (?, ?, ?, ?, ?)
                ');
                $stmt->execute([
                    $id,
                    $item['servico_id'],
                    $item['quantidade'],
                    $item['valor_unitario'],
                    $item['valor_total']
                ]);
            }
            
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log('Erro ao atualizar orçamento: ' . $e->getMessage());
            return false;
        }
    }
    
    public function atualizarStatus($id, $status) {
        try {
            $stmt = $this->db->prepare('UPDATE orcamentos SET status = ? WHERE id = ?');
            return $stmt->execute([$status, $id]);
        } catch (PDOException $e) {
            error_log('Erro ao atualizar status do orçamento: ' . $e->getMessage());
            return false;
        }
    }
    
    public function duplicar($id) {
        try {
            $orcamento = $this->getById($id);
            if (!$orcamento) {
                return false;
            }
            
            $itens = array_map(function($item) {
                return [
                    'servico_id' => $item['servico_id'],
                    'quantidade' => $item['quantidade'],
                    'valor_unitario' => $item['valor_unitario'],
                    'valor_total' => $item['valor_total']
                ];
            }, $orcamento['itens']);
            
            return $this->criar($orcamento['cliente']['id'], $orcamento['observacoes'], $itens);
        } catch (PDOException $e) {
            error_log('Erro ao duplicar orçamento: ' . $e->getMessage());
            return false;
        }
    }
    
    public function excluir($id) {
        try {
            $this->db->beginTransaction();
            
            // Remover itens
            $stmt = $this->db->prepare('DELETE FROM orcamento_itens WHERE orcamento_id = ?');
            $stmt->execute([$id]);
            
            // Remover orçamento
            $stmt = $this->db->prepare('DELETE FROM orcamentos WHERE id = ?');
            $stmt->execute([$id]);
            
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log('Erro ao excluir orçamento: ' . $e->getMessage());
            return false;
        }
    }
    
    // Métodos para modelos de orçamento
    public function listarModelos() {
        try {
            $stmt = $this->db->query('SELECT * FROM modelos_orcamento ORDER BY nome');
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Erro ao listar modelos: ' . $e->getMessage());
            return [];
        }
    }
    
    public function getItensModelo($modelo_id) {
        try {
            $stmt = $this->db->prepare('
                SELECT mi.*, s.nome as servico_nome, s.valor_unitario, s.unidade_medida
                FROM modelo_orcamento_itens mi
                JOIN servicos s ON mi.servico_id = s.id
                WHERE mi.modelo_id = ?
            ');
            $stmt->execute([$modelo_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Erro ao obter itens do modelo: ' . $e->getMessage());
            return [];
        }
    }
    
    public function salvarModelo($nome, $descricao, $itens) {
        try {
            $this->db->beginTransaction();
            
            // Inserir modelo
            $stmt = $this->db->prepare('
                INSERT INTO modelos_orcamento (nome, descricao)
                VALUES (?, ?)
            ');
            $stmt->execute([$nome, $descricao]);
            $modelo_id = $this->db->lastInsertId();
            
            // Inserir itens do modelo
            foreach ($itens as $item) {
                $stmt = $this->db->prepare('
                    INSERT INTO modelo_orcamento_itens (modelo_id, servico_id, quantidade)
                    VALUES (?, ?, ?)
                ');
                $stmt->execute([
                    $modelo_id,
                    $item['servico_id'],
                    $item['quantidade']
                ]);
            }
            
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log('Erro ao salvar modelo: ' . $e->getMessage());
            return false;
        }
    }
    
    public function excluirModelo($modelo_id) {
        try {
            $this->db->beginTransaction();
            
            // Remover itens do modelo
            $stmt = $this->db->prepare('DELETE FROM modelo_orcamento_itens WHERE modelo_id = ?');
            $stmt->execute([$modelo_id]);
            
            // Remover modelo
            $stmt = $this->db->prepare('DELETE FROM modelos_orcamento WHERE id = ?');
            $stmt->execute([$modelo_id]);
            
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log('Erro ao excluir modelo: ' . $e->getMessage());
            return false;
        }
    }
}
?>
